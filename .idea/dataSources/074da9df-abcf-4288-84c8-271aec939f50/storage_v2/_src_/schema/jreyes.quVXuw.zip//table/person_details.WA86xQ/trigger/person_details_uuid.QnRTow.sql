create definer = root@localhost trigger person_details_uuid
    before insert
    on person_details
    for each row
BEGIN
 IF new.id = '-'
    THEN
  SET new.id = (SELECT uuid());
 END IF;
END;

